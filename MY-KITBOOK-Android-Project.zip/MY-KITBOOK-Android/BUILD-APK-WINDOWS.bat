@echo off
echo Open this folder in Android Studio and build APK from Build menu.
pause
