MY-KITBOOK Android App project
==============================

এই ZIP-এ তোমার সর্বশেষ MY-KITBOOK 5.3 Receive Auto Due Fix HTML-কে Android WebView অ্যাপের মধ্যে রাখা হয়েছে।
এটি APK ফাইল নয়; Android Studio দিয়ে APK build করার সম্পূর্ণ project source।

গুরুত্বপূর্ণ:
- মূল HTML-এর হিসাব/ডেটাবেস কোড পরিবর্তন করা হয়নি।
- Supabase URL ও publishable key আগের HTML থেকেই রাখা হয়েছে।
- অ্যাপটি অনলাইনে Supabase ও প্রয়োজনীয় CDN ব্যবহার করে; ইন্টারনেট ছাড়া login/sync কাজ করবে না।
- ওয়েবসাইট ও অ্যাপ একই Supabase project ব্যবহার করলে একই cloud data দেখা যাবে।
- অ্যাপের local HTML কপি; পরবর্তীতে ওয়েবসাইটে HTML update করলে APK-তেও নতুন build দিতে হবে।

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করো।
2. ZIP extract করে Android Studio-তে 'MY-KITBOOK-Android' folder Open করো।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করো।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপো।
5. build/outputs/apk/debug/app-debug.apk ফাইলটি ফোনে নিয়ে install করো।

প্রয়োজন: Android Studio, Android SDK Platform 35, JDK 17।
